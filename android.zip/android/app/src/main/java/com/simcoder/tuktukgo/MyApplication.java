package com.simcoder.tuktukgo;

import android.app.Application;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Initialize any libraries here, e.g., OneSignal, Firebase, etc.
    }
}